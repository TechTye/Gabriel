<?php
	session_start();
	//Incluindo a conexão com banco de dados
	require_once("php/conexao.php");
	//O campo usuário e senha preenchido entra no if para validar
	if((isset($_POST['fun_email'])) && (isset($_POST['fun_senha']))){
		$usuario = mysqli_real_escape_string($con, $_POST['fun_email']); //Escapar de caracteres especiais, como aspas, prevenindo SQL injection
		$senha = mysqli_real_escape_string($con, $_POST['fun_senha']);
		//Buscar na tabela usuario o usuário que corresponde com os dados digitado no formulário
		$result_usuario = "SELECT * FROM funcionario WHERE fun_email = '$usuario' and fun_senha = '$senha' LIMIT 1";
		$resultado_usuario = mysqli_query($con, $result_usuario);
		$resultado = mysqli_fetch_assoc($resultado_usuario);

		//Encontrado um usuario na tabela usuário com os mesmos dados digitado no formulário
		if(isset($resultado)){
			$_SESSION['usuarioId'] = $resultado['fun_cod'];
			$_SESSION['usuarioNome'] = $resultado['fun_nome'];
			$_SESSION['usuarioNiveisAcessoId'] = $resultado['fun_perm'];
			$_SESSION['usuarioEmail'] = $resultado['fun_email'];
			var_dump($_SESSION['usuarioId']);
			if($_SESSION['usuarioNiveisAcessoId'] == "1"){
				header("Location: php/adm.php");
			}elseif($_SESSION['usuarioNiveisAcessoId'] == "2"){
				header("Location: php/dev.php");
			}else{
				header("Location: index.php");
			}

		}else{
			//Váriavel global recebendo a mensagem de erro
			$_SESSION['loginErro'] = "Usuário ou senha Inválido";
			header("Location: index.php");
		}
	//O campo usuário e senha não preenchido entra no else e redireciona o usuário para a página de login
	}else{
		$_SESSION['loginErro'] = "Usuário ou senha inválido";
		header("Location: index.php");
	}
?>