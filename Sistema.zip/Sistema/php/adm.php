<?php 

    include_once("conexao.php");

    session_start();
 
    if(isset($_SESSION['usuarioId']))
    {
    }
    else
    {
        header("location:../index.php");
    }
 ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>TechTye - Administrativo</title>

  <link rel="stylesheet" type="text/css" href="../lib/fontawesome-free-5.8.1-web/css/all.css">

  <link href="../lib/css/bootstrap.min.css" rel="stylesheet">

  <link href="../lib/css/mdb.min.css" rel="stylesheet">

  <link href="../lib/css/style.css" rel="stylesheet">
</head>

<body>
  <!-- Menu de Navegação -->
    <nav class="navbar navbar-expand-sm navbar-light bg-light">
      <a href="adm.php" class="navbar-brand text-dark">&nbsp;&nbsp;TechTye</a>
        <button class="navbar-toggler " data-toggle="collapse" data-target="#menu"> 
          <span class="navbar-toggler-icon"></span>
        </button>
      <div class="collapse navbar-collapse" id="menu">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="adm.php" class="nav-link">
              <i class="fas fa-chart-bar"></i> Dashboard</a>
          </li>
          <li class="nav-item">
            <a href="administrativo/contrato.php" class="nav-link">
              <i class="fas fa-clipboard-list"></i> Contratos</a>
          </li>
          <li class="nav-item">
            <a href="administrativo/tarefa.php" class="nav-link">
              <i class="fas fa-clipboard-list"></i> Tarefas</a>
          </li>
          <li class="nav-item">
            <a href="administrativo/funcionario.php" class="nav-link">
            <i class="fas fa-user-cog"></i> Funcionários</a>
          </li>
          <li class="nav-item">
            <a href="administrativo/cliente.php" class="nav-link">
              <i class="fas fa-users"></i> Clientes</a>
          </li>
        </ul>
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a href="" class="nav-link">
              <i class="fas fa-id-badge"></i> Perfil</a>
          </li>
          <li class="nav-item">
            <?php
              $_SESSION['logindeslogado'] = "Deslogado com sucesso brow";
                echo '<a href="logout.php?logout=$_SESSION["usuarioId"]" class="nav-link">Sair
              <i class="fas fa-sign-out-alt"></i></a>'
            ?>
          </li>
        </ul>
      </div>
    </nav>
  <!-- Final do Menu de Navegação -->
  <!-- Cabeçalho do Dashboard -->
    <div class=" py-3 text-white" style="background-color: teal">
      <h1>&nbsp;&nbsp;<i class="fas fa-chart-bar"></i>
        <?php
            echo ' Bem vindo ' . $_SESSION['usuarioNome'].'<br/>';
        ?></h1>
    </div>
    <div class="bg-light p-3">
     
    <div class="row">
       <div class="col-md-3">
         <a href="administrativo/cadContrato.php" class="btn btn-primary d-block font-weight-bold">
          <i class="fas fa-plus"></i> &nbsp;CONTRATO</a>
       </div>
       <div class="col-md-3">
         <a href="administrativo/cadCliente.php" class="btn btn-success d-block font-weight-bold">
          <i class="fas fa-plus"></i> &nbsp;CLIENTE</a>
       </div>
       <div class="col-md-3">
         <a href="administrativo/cadFuncionario.php" class="btn btn-warning d-block font-weight-bold">
          <i class="fas fa-plus"></i> &nbsp;FUNCIONÁRIO</a>
       </div>
       <div class="col-md-3">
         <a href="administrativo/cadTarefa.php" class="btn btn-danger d-block font-weight-bold">
          <i class="fas fa-plus"></i> &nbsp;TAREFA</a>
       </div>
    </div>
  </div>
  <!-- Final do Cabeçalho -->
  <!-- Conteúdo do Dashboard -->
  <div class="container-fluid">
    
    <div class="row"> 
      <div class="col-8">
        <h2 style="background-color: purple;" class="text-white p-3 ">Contratos da TechTye</h2>
        <div class="container">
        <!-- Criação da tabela -->
        <table class="table mt-3">
          <thead class="table-dark">
            <tr>
              <th>Nº</th>
              <th>Tarefa</th>
              <th>Descrição</th>
              <th>Requisitante</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
          <?php
            $result_horarios = "SELECT * FROM contrato LEFT JOIN cliente
            ON contrato.cnt_cliente = cliente.cli_cod";

            $resultado_horarios = mysqli_query($con, $result_horarios);

            while($row_horarios = mysqli_fetch_array($resultado_horarios)){
            echo"<tr>
                  <td>".$row_horarios['cnt_cod']."</td>
                  <td>".$row_horarios['cnt_titulo']."</td>
                  <td>".$row_horarios['cnt_descricao']."</td>
                  <td>".$row_horarios['cli_nome']."</td>
                  <td><a href='administrativo/contrato.php' class='btn btn-outline-secondary btn-sm'>
                         Detalhes <i></i>
                  </a></td>
                </tr>";
            }
          ?>
          </tbody>
        </table>
      </div>
    </div>
      <div class="col-md-4 mt-4">
          <div class="card">
            <div class=" bg-warning text-white p-4">
              <i class="fas fa-list-ul fa-6x"></i>
              <h2 class="float-right font-weight-bold" style="font-size: 40px; text-align: center;">08 <span class="d-block"> Desenvolvimento</span></h2>
            </div>
            <div class="card-footer text-primary">
              <h6 class="text-center"><a href=""> Ver Detalhes
              <i class="fas fa-arrow-alt-circle-right"></i></h6></a>
            </div>
          </div>
          <div class="card mt-5">
            <div class=" bg-success text-white p-4 ">
              <i class="fas fa-list-ul fa-6x"></i>
              <h2 class="float-right font-weight-bold" style="font-size: 40px; text-align: center;">04 <span class="d-block">Concluídos</span></h2>
            </div>
            <div class="card-footer text-primary">
              <h6 class="text-center"><a href=""> Ver Detalhes
              <i class="fas fa-arrow-alt-circle-right"></i></h6></a>
            </div>
          </div>
          <div class="card mt-5">
            <div class=" bg-danger text-white p-4 ">
              <i class="fas fa-list-ul fa-6x"></i>
              <h2 class="float-right font-weight-bold" style="font-size: 40px; text-align: center;">20 <span class="d-block"> Em Atraso</span></h2>
            </div>
            <div class="card-footer text-warning">
              <h6 class="text-center"><a href=""> Ver Detalhes
              <i class="fas fa-arrow-alt-circle-right"></i></h6></a>
            </div>
          </div>
      </div> 
    </div>
  
  <!-- Final do conteúdo do Dashboard -->

  <script type="text/javascript" src="../lib/js/jquery-3.3.1.min.js"></script>

  <script type="text/javascript" src="../lib/js/popper.min.js"></script>

  <script type="text/javascript" src="../lib/js/bootstrap.min.js"></script>

  <script type="text/javascript" src="../lib/js/mdb.min.js"></script>
</body>

</html>