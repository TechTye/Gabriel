<?php 
	session_start();
 
    if(isset($_SESSION['usuarioId']))
    {
        echo ' Bem vindo ' . $_SESSION['usuarioNome'].'<br/>';
        echo '<a href="logout.php?logout=$_SESSION["usuarioId"]">Logout</a>';
    }
    else
    {
        header("location:../index.php");
    }
 ?>