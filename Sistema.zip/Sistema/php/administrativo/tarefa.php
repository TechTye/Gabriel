<?php 

    include_once("../conexao.php");

    session_start();
 
    if(isset($_SESSION['usuarioId']))
    {
    }
    else
    {
        header("location:../index.php");
    }
 ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>TechTye - Contratos</title>

  <link rel="stylesheet" type="text/css" href="../../lib/fontawesome-free-5.8.1-web/css/all.css">

  <link href="../../lib/css/bootstrap.min.css" rel="stylesheet">

  <link href="../../lib/css/mdb.min.css" rel="stylesheet">

  <link href="../../lib/css/style.css" rel="stylesheet">
</head>

<body>
  <!-- Menu de Navegação -->
    <nav class="navbar navbar-expand-sm navbar-light bg-light">
      <a href="../adm.php" class="navbar-brand text-dark">&nbsp;&nbsp;TechTye</a>
        <button class="navbar-toggler " data-toggle="collapse" data-target="#menu"> 
          <span class="navbar-toggler-icon"></span>
        </button>
      <div class="collapse navbar-collapse" id="menu">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="../adm.php" class="nav-link">
              <i class="fas fa-chart-bar"></i> Dashboard</a>
          </li>
          <li class="nav-item">
            <a href="contrato.php" class="nav-link">
              <i class="fas fa-clipboard-list"></i> Contratos</a>
          </li>
          <li class="nav-item">
            <a href="tarefa.php" class="nav-link">
              <i class="fas fa-clipboard-list"></i> Tarefas</a>
          </li>
          <li class="nav-item">
            <a href="funcionario.php" class="nav-link">
            <i class="fas fa-user-cog"></i> Funcionários</a>
          </li>
          <li class="nav-item">
            <a href="cliente.php" class="nav-link">
              <i class="fas fa-users"></i> Clientes</a>
          </li>
        </ul>
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a href="" class="nav-link">
              <i class="fas fa-id-badge"></i> Perfil</a>
          </li>
          <li class="nav-item">
            <?php
                echo '<a href="../logout.php?logout" class="nav-link">Sair
              <i class="fas fa-sign-out-alt"></i></a>'
            ?>
          </li>
        </ul>
      </div>
    </nav>
  <!-- Final do Menu de Navegação -->
  <!-- Cabeçalho do Dashboard -->
    <div class=" py-3 text-white" style="background-color: teal">
      <h1>&nbsp;&nbsp;<i class="fas fa-users"></i> Minhas Tarefas</h1>
    </div>
  </div>
  <!-- Final do Cabeçalho -->
  <!-- Conteúdo do Dashboard -->
  <div class="container-fluid">
    
    <div class="row"> 
      <div class="col-12">
        <h2 style="background-color: purple;" class="text-white p-3 text-center">Minhas Tarefas</h2>
        <div class="container">
        <!-- Criação da tabela -->
        <table class="table mt-4">
          <thead class="table-dark">
            <tr>
              <th>Tarefa</th>
              <th>Status</th>
              <th>Observação</th>
              <th>Contrato</th>
              <th>Responsável</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
          <?php
            $result_usuarios = "SELECT *, funcionario.fun_cod, contrato.cnt_cod 
            FROM ((tarefa
            INNER JOIN funcionario ON tarefa.trf_func = funcionario.fun_cod)
            INNER JOIN contrato ON tarefa.trf_contrato = contrato.cnt_cod)";

            $resultado_usuarios = mysqli_query($con, $result_usuarios);

            while($row_usuarios = mysqli_fetch_array($resultado_usuarios)){
            echo"<tr>
                  <td>".$row_usuarios['trf_titulo']."</td>
                  <td>".$row_usuarios['trf_status']."</td>
                  <td>".$row_usuarios['trf_obs']."</td>
                  <td>".$row_usuarios['cnt_titulo']."</td>
                  <td>".$row_usuarios['fun_nome']."</td>
                  <td><button type='button' class='btn btn-outline-secondary btn-sm' data-toggle='modal' data-target='#modalExemplo'>
                    Alterar
                  </button></td>
                </tr>";
            }
          ?>
          </tbody>
        </table>
      </div>
    </div> 
    </div>
  
  <!-- Final do conteúdo do Dashboard -->

  <script type="text/javascript" src="lib/js/jquery-3.3.1.min.js"></script>

  <script type="text/javascript" src="lib/js/popper.min.js"></script>

  <script type="text/javascript" src="lib/js/bootstrap.min.js"></script>

  <script type="text/javascript" src="lib/js/mdb.min.js"></script>
</body>

</html>