<?php
session_start();
//Conexao com BD
include_once("../conexao.php");

//Receber os dados do formulário
$nome = $_REQUEST['inputNome'];
$email = $_REQUEST['inputEmail'];
$telefone = $_REQUEST['inputTelefone'];
$CNPJ = $_REQUEST['inputCNPJ'];

//Salvar no BD
$result_data = "INSERT INTO cliente (cli_nome, cli_email, cli_telefone, cli_CNPJ) VALUES ('$nome',''$email','$telefone','$CNPJ')";
$resultado_data = mysqli_query($con, $result_data);

//Verificar se salvou no banco de dados através "mysqli_insert_id" o qual verifica se existe o ID do último dado inserido
if(mysqli_insert_id($con)){
	$_SESSION['msg'] = "<div class='alert alert-success'> Cliente cadastrado com sucesso </div>";
	header("Location: ../cadCliente.php");
}else{
	$_SESSION['msg'] = "<div class='alert alert-primary' role='alert'>
  		Erro ao cadastrar! </div>";
	header("Location: ../cadCliente.php");
}

