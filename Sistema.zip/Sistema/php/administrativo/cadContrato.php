<?php 

    include_once("../conexao.php");

    session_start();
 
    if(isset($_SESSION['Adm']))
    {
    }
    else
    {
        header("location:../index.php");
    }
 ?>
 <!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>TechTye - Administrativo</title>

  <link rel="stylesheet" type="text/css" href="../../lib/fontawesome-free-5.8.1-web/css/all.css">

  <link href="../../lib/css/bootstrap.min.css" rel="stylesheet">

  <link href="../../lib/css/mdb.min.css" rel="stylesheet">

  <link href="../../lib/css/style.css" rel="stylesheet">
</head>

<body>
  <!-- Menu de Navegação -->
    <nav class="navbar navbar-expand-sm navbar-light bg-light">
      <a href="../adm.php" class="navbar-brand text-dark">&nbsp;&nbsp;TechTye</a>
        <button class="navbar-toggler " data-toggle="collapse" data-target="#menu"> 
          <span class="navbar-toggler-icon"></span>
        </button>
      <div class="collapse navbar-collapse" id="menu">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="../adm.php" class="nav-link">
              <i class="fas fa-chart-bar"></i> Dashboard</a>
          </li>
          <li class="nav-item">
            <a href="contrato.php" class="nav-link">
              <i class="fas fa-clipboard-list"></i> Contratos</a>
          </li>
          <li class="nav-item">
            <a href="tarefa.php" class="nav-link">
              <i class="fas fa-clipboard-list"></i> Tarefas</a>
          </li>
          <li class="nav-item">
            <a href="funcionario.php" class="nav-link">
            <i class="fas fa-user-cog"></i> Funcionários</a>
          </li>
          <li class="nav-item">
            <a href="cliente.php" class="nav-link">
              <i class="fas fa-users"></i> Clientes</a>
          </li>
        </ul>
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a href="" class="nav-link">
              <i class="fas fa-id-badge"></i> Perfil</a>
          </li>
          <li class="nav-item">
            <?php
                echo '<a href="../logout.php?logout" class="nav-link">Sair
              <i class="fas fa-sign-out-alt"></i></a>'
            ?>
          </li>
        </ul>
      </div>
    </nav>
  <!-- Final do Menu de Navegação -->
  <!-- Cabeçalho do Dashboard -->
  <div class="container-fluid">
    
    <div class="row"> 
      <div class="col-12">
        <h2 style="background-color: purple;" class="text-white p-3 text-center">Gerar Contrato</h2>
        <div class="container">
          <br><form action="cdstContrato.php" method="POST">
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="inputTarefa"><b>Tarefa</b></label>
              <input type="text" class="form-control" name="inputTarefa" placeholder="Tarefa">
            </div>
            <div class="form-group col-md-6">
              <label for="inputDescricao"><b>Descrição</b></label>
              <input type="text" class="form-control" name="inputDescricao" placeholder="Descrição">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="dtaAbertura"><b>Data de Abertura</b></label>
              <div class="input-group date data_formato" data-date-format="dd/mm/yyyy HH:ii:ss">
                <input type="text" class="form-control" name="dtaAbertura" placeholder="Data de Abertura">
                <span class="input-group-addon">
                  <span class="glyphicon glyphicon-th"></span>
                </span>
              </div> 
            </div>
            <div class="form-group col-md-6">
              <label for="dtaConclusao"><b>Data de Conclusão</b></label>
              <div class="input-group date data_formato" data-date-format="dd/mm/yyyy HH:ii:ss">
                <input type="text" class="form-control" name="dtaConclusao" placeholder="Data de Conclusão">
                <span class="input-group-addon">
                  <span class="glyphicon glyphicon-th"></span>
                </span>
              </div>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="inputResp"><b>Responsável</b></label>
              <select name="inputResp" class="form-control">
                <option selected>Escolher...</option>
                <?php 

                  $result_resp = "SELECT * FROM funcionario";

                  $resultado_resp = mysqli_query($con, $result_resp);

                  while($row_resp = mysqli_fetch_array($resultado_resp)){
                    echo"<option>".$row_resp['fun_nome']."</option>";
                  }
                ?>
              </select>
            </div>
            <div class="form-group col-md-6">
              <label for="inputRequis"><b>Requisitante</b></label>
              <select name="inputRequis" class="form-control">
                <option selected>Escolher...</option>
                <?php 

                  $result_requi = "SELECT * FROM cliente";

                  $resultado_requi = mysqli_query($con, $result_requi);

                  while($row_requi = mysqli_fetch_array($resultado_requi)){
                    echo"<option>".$row_requi['cli_nome']."</option>";
                  }
                ?>
              </select>
            </div>
            <div class="form-group col-md-8">
              <label for="inputPrioridade"><b>Prioridade</b></label>
              <select name="inputPrioridade" class="form-control">
                <option selected>Escolher...</option>
                <option>ALTA</option>
                <option>MÉDIA</option>
                <option>BAIXA</option>
              </select>
            </div>
            <div class="form-group col-md-4">
              <label for="inputStatus"><b>Status</b></label>
              <select name="inputStatus" class="form-control">
                <option selected>Escolher...</option>
                <option>EM ANÁLISE</option>
                <option>EM DESENVOLVIMENTO</option>
                <option>EM ATRASO</option>
              </select>
            </div>
          </div>
          <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Cadastrar</button>
        </form>
      </div>
    </div>
    </div>
  <!-- Final do conteúdo do Dashboard -->

  <script type="text/javascript" src="../../lib/js/jquery-3.3.1.min.js"></script>

  <script type="text/javascript" src="../../lib/js/popper.min.js"></script>

  <script type="text/javascript" src="../../lib/js/bootstrap.min.js"></script>

  <script type="text/javascript" src="../../lib/js/mdb.min.js"></script>

  <script src="../../lib/js/bootstrap-datetimepicker.min.js"></script>

  <script src="../../lib/js/locales/bootstrap-datetimepicker.pt-BR.js"></script>
    
  <script type="text/javascript">
      $('.data_formato').datetimepicker({
        weekStart: 1,
        todayBtn: 1,
        autoclose: 1,
        todayHighlight: 1,
        startView: 2,
        forceParse: 0,
        showMeridian: 1,
        language: "pt-BR",
        //startDate: '+0d'
      });
  </script>
</body>

</html>