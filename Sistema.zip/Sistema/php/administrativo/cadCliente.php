<?php 

    include_once("../conexao.php");

    session_start();
 
    if(isset($_SESSION['Adm']))
    {
    }
    else
    {
        header("location:../index.php");
    }
 ?>
 <!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>TechTye - Administrativo</title>

  <link rel="stylesheet" type="text/css" href="../../lib/fontawesome-free-5.8.1-web/css/all.css">

  <link href="../../lib/css/bootstrap.min.css" rel="stylesheet">

  <link href="../../lib/css/mdb.min.css" rel="stylesheet">

  <link href="../../lib/css/style.css" rel="stylesheet">
</head>

<body>
  <!-- Menu de Navegação -->
    <nav class="navbar navbar-expand-sm navbar-light bg-light">
      <a href="../adm.php" class="navbar-brand text-dark">&nbsp;&nbsp;TechTye</a>
        <button class="navbar-toggler " data-toggle="collapse" data-target="#menu"> 
          <span class="navbar-toggler-icon"></span>
        </button>
      <div class="collapse navbar-collapse" id="menu">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="../adm.php" class="nav-link">
              <i class="fas fa-chart-bar"></i> Dashboard</a>
          </li>
          <li class="nav-item">
            <a href="contrato.php" class="nav-link">
              <i class="fas fa-clipboard-list"></i> Contratos</a>
          </li>
          <li class="nav-item">
            <a href="tarefa.php" class="nav-link">
              <i class="fas fa-clipboard-list"></i> Tarefas</a>
          </li>
          <li class="nav-item">
            <a href="funcionario.php" class="nav-link">
            <i class="fas fa-user-cog"></i> Funcionários</a>
          </li>
          <li class="nav-item">
            <a href="cliente.php" class="nav-link">
              <i class="fas fa-users"></i> Clientes</a>
          </li>
        </ul>
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a href="" class="nav-link">
              <i class="fas fa-id-badge"></i> Perfil</a>
          </li>
          <li class="nav-item">
            <?php
                echo '<a href="../logout.php?logout" class="nav-link">Sair
              <i class="fas fa-sign-out-alt"></i></a>'
            ?>
          </li>
        </ul>
      </div>
    </nav>
  <!-- Final do Menu de Navegação -->
  <!-- Cabeçalho do Dashboard -->
  <div class="container-fluid">
    <div class="row"> 
      <div class="col-12">
        <h2 style="background-color: purple;" class="text-white p-3 text-center">Novo Cliente</h2>
        <div class="container">
          <br><form action="acoes/cadastraCliente.php" method="POST">
          <div class="form-row">
            <div class="form-group col-md-12">
              <label for="inputNome"><b>Nome da Empresa</b></label>
              <input type="text" class="form-control" name="inputNome" placeholder="Nome da Empresa">
            </div>
            <div class="form-group col-md-12">
              <label for="inputEmail"><b>Email</b></label>
              <input type="text" class="form-control" name="inputEmail" placeholder="Empresa@gmail.com">
            </div>
            <div class="form-group col-md-12">
              <label for="inputCNPJ"><b>CNPJ</b></label>
              <input type="text" class="form-control" id="cnpj" name="inputCNPJ" placeholder="xx.xxx.xxx/0001-??">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-12">
              <label for="inputTelefone"><b>Contato</b></label>
              <input type="text" class="form-control" id="telefone" name="inputTelefone" placeholder="(11) 3333-3333" maxlength="15">
            </div>
          </div>
          <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Cadastrar</button>
        </form>
      </div>
    </div>
  </div>
  <!-- Final do conteúdo do Dashboard -->

  <script type="text/javascript" src="../../lib/js/jquery-3.3.1.min.js"></script>

  <script type="text/javascript" src="../../lib/js/popper.min.js"></script>

  <script type="text/javascript" src="../../lib/js/bootstrap.min.js"></script>

  <script type="text/javascript" src="../../lib/js/mdb.min.js"></script>

  <script src="../../lib/js/jquery-1.2.6.pack.js" type="text/javascript"></script>

  <script src="../../lib/js/jquery.maskedinput-1.1.4.pack.js" type="text/javascript" /></script>

  <script type="text/javascript">
    $(document).ready(function(){ 
      $("#cnpj").mask("99.999.999/9999-99");
    });
  </script>

  <script type="text/javascript">
    /* Máscara TEL */
    function mascara(o,f){
        v_obj=o
        v_fun=f
        setTimeout("execmascara()",1)
    }
    function execmascara(){
        v_obj.value=v_fun(v_obj.value)
    }
    function mtel(v){
        v=v.replace(/\D/g,"");             //Remove tudo o que não é dígito
        v=v.replace(/^(\d{2})(\d)/g,"($1) $2"); //Coloca parênteses em volta dos dois primeiros dígitos
        v=v.replace(/(\d)(\d{4})$/,"$1-$2");    //Coloca hífen entre o quarto e o quinto dígitos
        return v;
    }
    function id( el ){
      return document.getElementById( el );
    }
    window.onload = function(){
      id('telefone').onkeyup = function(){
        mascara( this, mtel );
      }
    }
</script>

</body>

</html>