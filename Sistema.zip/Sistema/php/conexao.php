<?php 
	$con = mysqli_connect('localhost','root','1234','techtye');
 
    if(!$con)
    {
        die(' Por favor, cheque a sua conexão.'.mysqli_error($con));
    }
 ?>