<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <title>Área Restrita - Techtye Tecnologia</title>
</head>
<body>
    <div class="container">

      <form class="form-signin" method="POST" action="verifica-dados.php">
        <h2 class="form-signin-heading">Área Restrita</h2>
        <label for="inputEmail" class="sr-only">Email</label>
        <input type="email" name="fun_email" id="fun_email" class="form-control" placeholder="Email" required autofocus>
        <label for="inputPassword" class="sr-only">Senha</label>
        <input type="password" name="fun_senha" id="fun_senha" class="form-control" placeholder="Senha" required>
        <button class="btn btn-lg btn-success btn-block" type="submit">Acessar</button>
        
      </form>
      <p class="text-center text-danger">
            <?php if(isset($_SESSION['loginErro'])){
                echo $_SESSION['loginErro'];
                unset($_SESSION['loginErro']);
            }?>
        </p>
        <p class="text-center text-success">
            <?php 
            if(isset($_SESSION['logindeslogado'])){
                echo $_SESSION['logindeslogado'];
                unset($_SESSION['logindeslogado']);
            }?>
        </p>
    </div>
</body>
</html>